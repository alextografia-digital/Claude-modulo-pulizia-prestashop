<?php
/**
 * Endpoint per l'esecuzione automatica (cron) e per il pulsante "Esegui tutto automaticamente".
 *
 * Testo (cron):
 *   https://tuosito.it/module/cleanunusedimages/cron?token=XXXX&mode=demo
 *   https://tuosito.it/module/cleanunusedimages/cron?token=XXXX&mode=delete
 *
 * JSON (usato dalla pagina del modulo, a passi brevi con budget di tempo):
 *   .../cron?token=XXXX&format=json&mode=delete&budget=20&cui_tasks[]=db_log&cui_params[db_log]=90
 *
 * Senza cui_tasks vengono eseguite le pulizie selezionate e salvate nella pagina di configurazione.
 * Senza il parametro mode=delete viene sempre eseguita la modalita' demo.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CleanunusedimagesCronModuleFrontController extends ModuleFrontController
{
    const MAX_BUDGET = 40;

    public function initContent()
    {
        $json = Tools::getValue('format') === 'json';
        header('Content-Type: ' . ($json ? 'application/json' : 'text/plain') . '; charset=utf-8');

        $expected = (string) Configuration::getGlobalValue(Cleanunusedimages::CFG_TOKEN);
        $given = (string) Tools::getValue('token');
        if ($expected === '' || !hash_equals($expected, $given)) {
            $this->fail('403 Forbidden', 'Token non valido.', $json);
        }

        $doDelete = Tools::getValue('mode') === 'delete';
        $posted = Tools::getValue('cui_tasks');
        $settings = is_array($posted) ? CuiCleanupManager::settingsFromRequest() : CuiCleanupManager::loadSettings();
        $defs = CuiCleanupManager::definitions();

        // Con un budget di tempo il lavoro si ferma da solo e va ripreso con una nuova richiesta;
        // senza budget (cron) non c'e' limite e, se richiesto, le tabelle vengono ottimizzate.
        $budget = (float) Tools::getValue('budget');
        $budget = $budget > 0 ? min($budget, self::MAX_BUDGET) : null;

        if (empty($settings['tasks'])) {
            if ($json) {
                exit(json_encode(['mode' => $doDelete ? 'delete' : 'demo', 'done' => true, 'rows' => []]));
            }
            exit("Nessuna pulizia selezionata nelle impostazioni del modulo.\n");
        }

        try {
            $run = CuiCleanupManager::run($settings, $doDelete, $budget);
        } catch (Exception $e) {
            $this->fail('500 Internal Server Error', $e->getMessage(), $json);
        }

        if ($json) {
            $rows = [];
            $done = true;
            foreach ($run['results'] as $key => $r) {
                if ($r['status'] === 'partial') {
                    $done = false;
                }
                $rows[] = [
                    'key' => $key,
                    'label' => $defs[$key]['label'],
                    'status' => $r['status'],
                    'count' => (int) $r['count'],
                    'bytes' => $r['bytes'],
                    'deleted' => (int) $r['deleted'],
                    'freed' => $r['freed'],
                    'failed' => (int) $r['failed'],
                    'note' => (string) $r['note'],
                ];
            }
            exit(json_encode([
                'mode' => $doDelete ? 'delete' : 'demo',
                'done' => $done,
                'rows' => $rows,
                'optimized' => $run['optimized'],
            ]));
        }

        $lines = [$doDelete ? 'Modalita\': PULIZIA' : 'Modalita\': DEMO (nessun dato eliminato)'];
        foreach ($run['results'] as $key => $r) {
            $line = $defs[$key]['label'] . ' [' . $r['status'] . ']: ' . $r['count'] . ' elementi';
            if ($r['bytes'] !== null) {
                $line .= ' (' . Tools::formatBytes($r['bytes'], 2) . ')';
            }
            if ($doDelete) {
                $line .= ', eliminati ' . $r['deleted'];
                if ($r['failed'] > 0) {
                    $line .= ', non eliminati ' . $r['failed'];
                }
            }
            $lines[] = $line;
            if ($r['note'] !== '') {
                $lines[] = '    ' . $r['note'];
            }
        }
        if (!empty($run['optimized'])) {
            $lines[] = 'Tabelle ottimizzate: ' . implode(', ', $run['optimized']);
        }

        exit(implode("\n", $lines) . "\n");
    }

    private function fail($status, $message, $json)
    {
        header('HTTP/1.1 ' . $status);
        exit($json ? json_encode(['error' => $message]) : $message . "\n");
    }
}
