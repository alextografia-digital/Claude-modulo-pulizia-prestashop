<form method="post" action="{$form_action|escape:'html':'UTF-8'}">

<div class="card">
  <h3 class="card-header"><i class="icon-trash"></i> Pulizia file e dati inutilizzati</h3>
  <div class="card-body">
    <p>
      Scegli le pulizie da eseguire. Ogni voce ha un'età minima: vengono toccati solo i dati più vecchi del periodo indicato.
      Le impostazioni scelte qui vengono salvate e usate anche dal cron.
      Inserendo <strong>0</strong> vengono eliminati tutti i dati fino a questo momento (dal giorno 0 in poi, quindi anche quelli di oggi).
      Un campo lasciato vuoto o negativo usa il valore predefinito, mai 0.
    </p>
    <div class="alert alert-warning">
      Parti sempre dalla <strong>scansione demo</strong>, che non elimina nulla. Prima di una pulizia definitiva fai un
      <strong>backup del database</strong> e della cartella <code>img/p/</code>: le eliminazioni non sono reversibili.
      La pulizia ricalcola tutto al momento del click, non usa i risultati della demo.
    </div>

    {foreach from=$groups item=group}
      <h4 class="mt-4">{$group.title|escape:'html':'UTF-8'}</h4>
      <table class="table table-striped">
        <thead>
          <tr>
            <th style="width:40px"></th>
            <th>Pulizia</th>
            <th style="width:230px">Età minima</th>
            <th style="width:170px">Rischio</th>
          </tr>
        </thead>
        <tbody>
        {foreach from=$group.tasks item=task}
          <tr>
            <td>
              <input type="checkbox" name="cui_tasks[]" value="{$task.key|escape:'html':'UTF-8'}"
                     id="cui_t_{$task.key|escape:'html':'UTF-8'}"{if $task.checked} checked{/if}>
            </td>
            <td>
              <label for="cui_t_{$task.key|escape:'html':'UTF-8'}" class="mb-0"><strong>{$task.label|escape:'html':'UTF-8'}</strong></label>
              <div class="text-muted">{$task.desc|escape:'html':'UTF-8'}</div>
            </td>
            <td>
              {if $task.has_param}
                <div class="form-inline">
                  {$task.param_label|escape:'html':'UTF-8'}&nbsp;
                  <input type="number" min="0" class="form-control form-control-sm" style="width:80px"
                         name="cui_params[{$task.key|escape:'html':'UTF-8'}]" value="{$task.param|intval}">&nbsp;{$task.unit|escape:'html':'UTF-8'}
                </div>
              {else}
                <span class="text-muted">-</span>
              {/if}
            </td>
            <td>
              {if $task.risk == 'low'}
                <span class="badge badge-success">{$task.risk_label|escape:'html':'UTF-8'}</span>
              {else}
                <span class="badge badge-warning">{$task.risk_label|escape:'html':'UTF-8'}</span>
              {/if}
            </td>
          </tr>
        {/foreach}
        </tbody>
      </table>
    {/foreach}

    <div class="form-check mb-3">
      <input type="checkbox" class="form-check-input" id="cui_optimize" name="cui_optimize" value="1"{if $optimize} checked{/if}>
      <label class="form-check-label" for="cui_optimize">
        Ottimizza le tabelle modificate dopo la pulizia (solo nell'esecuzione da cron: libera spazio su disco ma può richiedere tempo e bloccare brevemente le tabelle grandi, meglio fuori orario)
      </label>
    </div>

    <button type="submit" name="submitCuiScan" value="1" class="btn btn-primary">
      <i class="icon-search"></i> Scansione demo (non elimina nulla)
    </button>
    <button type="submit" name="submitCuiSave" value="1" class="btn btn-default">
      <i class="icon-save"></i> Salva impostazioni
    </button>
  </div>
</div>

{if $view}
<div class="card mt-3">
  <h3 class="card-header">
    {if $view.mode == 'delete'}Risultato della pulizia{else}Risultato della scansione (demo){/if}
  </h3>
  <div class="card-body">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Pulizia</th>
          <th class="text-right">Elementi trovati</th>
          <th class="text-right">Spazio file</th>
          {if $view.mode == 'delete'}
            <th class="text-right">Eliminati</th>
            <th class="text-right">Spazio liberato</th>
          {/if}
        </tr>
      </thead>
      <tbody>
      {foreach from=$view.rows item=row}
        <tr>
          <td>
            <strong>{$row.label|escape:'html':'UTF-8'}</strong>
            {if $row.status == 'skipped'}<span class="badge badge-secondary">saltata</span>{/if}
            {if $row.status == 'error'}<span class="badge badge-danger">errore</span>{/if}
            {if $row.status == 'partial'}<span class="badge badge-info">da continuare</span>{/if}
            {if $row.failed > 0}<span class="badge badge-danger">{$row.failed|intval} non eliminati</span>{/if}
            {if $row.note}<div class="text-muted">{$row.note|escape:'html':'UTF-8'}</div>{/if}
            {if $row.samples}
              <details>
                <summary>Esempi</summary>
                <ul class="mb-0">
                {foreach from=$row.samples item=sample}
                  <li><code>{$sample|escape:'html':'UTF-8'}</code></li>
                {/foreach}
                </ul>
              </details>
            {/if}
          </td>
          <td class="text-right">{$row.count|intval}</td>
          <td class="text-right">{$row.size|escape:'html':'UTF-8'}</td>
          {if $view.mode == 'delete'}
            <td class="text-right">{$row.deleted|intval}</td>
            <td class="text-right">{$row.freed|escape:'html':'UTF-8'}</td>
          {/if}
        </tr>
      {/foreach}
      </tbody>
    </table>
    {if $view.mode == 'delete'}
      <p>Spazio file liberato: <strong>{$view.total_freed|escape:'html':'UTF-8'}</strong>.
      {if $view.optimized}Tabelle ottimizzate: {foreach from=$view.optimized item=t name=o}{$t|escape:'html':'UTF-8'}{if !$smarty.foreach.o.last}, {/if}{/foreach}.{/if}</p>
    {else}
      <p>Spazio occupato dai file individuati: <strong>{$view.total_size|escape:'html':'UTF-8'}</strong>
      (le righe del database non hanno una dimensione calcolabile qui).</p>
    {/if}

    {if $view.mode == 'demo' or $view.has_partial}
      {if $view.has_partial and $view.mode == 'delete'}
        <div class="alert alert-info">
          Per non sovraccaricare il database, ogni esecuzione dal back office si ferma dopo circa 20 secondi.
          Alcune pulizie sono da continuare: premi di nuovo il pulsante finché non compare più "da continuare".
          Per svuotare grandi quantità di dati in un colpo solo usa il cron.
        </div>
      {/if}
      <div class="form-check mb-2">
        <input type="checkbox" class="form-check-input" id="cui_confirm" name="cui_confirm" value="1">
        <label class="form-check-label" for="cui_confirm">
          Confermo di aver fatto un backup del database e di <code>img/p/</code> e voglio eseguire la pulizia definitiva delle voci selezionate.
        </label>
      </div>
      <button type="button" id="cui_auto" class="btn btn-danger" data-url="{$cron_json|escape:'html':'UTF-8'}">
        <i class="icon-trash"></i> Esegui tutto automaticamente (consigliato)
      </button>
      <button type="button" id="cui_stop" class="btn btn-default" style="display:none">
        <i class="icon-stop"></i> Ferma
      </button>
      <button type="submit" name="submitCuiDelete" value="1" class="btn btn-default">
        {if $view.mode == 'demo'}Esegui un solo passo (circa 20 secondi){else}Continua con un solo passo{/if}
      </button>
      <p class="text-muted mt-2 mb-0">
        L'esecuzione automatica ripete da sola passi brevi finché ha finito e mostra l'avanzamento: non chiudere la pagina
        fino al messaggio finale. Se la interrompi, puoi riprendere in qualsiasi momento.
      </p>
      <div id="cui_progress" class="mt-3"></div>
    {/if}
  </div>
</div>
{/if}

</form>

{if $view}
{literal}
<script>
(function () {
  var btn = document.getElementById('cui_auto');
  if (!btn) { return; }
  if (!window.fetch || !window.URLSearchParams || !window.FormData) { btn.style.display = 'none'; return; }
  var stopBtn = document.getElementById('cui_stop');
  var box = document.getElementById('cui_progress');
  var stopped = false;
  stopBtn.addEventListener('click', function () { stopped = true; });

  function cell(tr, text, right) {
    var td = document.createElement('td');
    td.textContent = text;
    if (right) { td.className = 'text-right'; }
    tr.appendChild(td);
  }

  function render(totals, message, isError) {
    box.innerHTML = '';
    var msg = document.createElement('div');
    msg.className = 'alert ' + (isError ? 'alert-danger' : 'alert-info');
    msg.textContent = message;
    box.appendChild(msg);
    var table = document.createElement('table');
    table.className = 'table table-striped';
    var head = document.createElement('tr');
    ['Pulizia', 'Stato', 'Eliminati finora'].forEach(function (h, i) {
      var th = document.createElement('th');
      th.textContent = h;
      if (i === 2) { th.className = 'text-right'; }
      head.appendChild(th);
    });
    table.appendChild(head);
    Object.keys(totals).forEach(function (key) {
      var t = totals[key];
      var tr = document.createElement('tr');
      cell(tr, t.label + (t.note ? ' - ' + t.note : ''), false);
      cell(tr, t.status === 'partial' ? 'in corso' : (t.stalled ? 'ferma' : (t.status === 'ok' ? 'completata' : t.status)), false);
      cell(tr, String(t.deleted), true);
      table.appendChild(tr);
    });
    box.appendChild(table);
  }

  function query(form, pending) {
    var p = new URLSearchParams();
    new FormData(form).forEach(function (v, k) {
      if (k.indexOf('cui_') !== 0 || k === 'cui_confirm' || k === 'cui_tasks[]') { return; }
      p.append(k, v);
    });
    pending.forEach(function (key) { p.append('cui_tasks[]', key); });
    p.append('mode', 'delete');
    p.append('budget', '20');
    return p.toString();
  }

  btn.addEventListener('click', async function () {
    var confirmBox = document.getElementById('cui_confirm');
    if (!confirmBox || !confirmBox.checked) {
      alert('Spunta prima la casella di conferma.');
      return;
    }
    var form = btn.form;
    var pending = new FormData(form).getAll('cui_tasks[]');
    if (!pending.length) { alert('Seleziona almeno una pulizia.'); return; }
    var totals = {};
    var baseUrl = btn.getAttribute('data-url');
    stopped = false;
    btn.disabled = true;
    stopBtn.style.display = '';
    try {
      for (var step = 1; step <= 2000 && pending.length && !stopped; step++) {
        render(totals, 'Passo ' + step + ' in corso...', false);
        var resp = await fetch(baseUrl + '&' + query(form, pending), { credentials: 'same-origin' });
        var text = await resp.text();
        var data;
        try { data = JSON.parse(text); } catch (e) {
          throw new Error('Risposta non valida dal server (' + resp.status + '): ' + text.substring(0, 200));
        }
        if (!resp.ok || data.error) { throw new Error(data.error || ('Errore ' + resp.status)); }
        pending = [];
        data.rows.forEach(function (r) {
          var t = totals[r.key] || (totals[r.key] = { label: r.label, deleted: 0, stall: 0 });
          t.deleted += r.deleted;
          t.status = r.status;
          t.note = r.note;
          // senza progressi per 3 passi consecutivi (escluse le pulizie non ancora arrivate al loro turno) ci si ferma
          if (r.deleted > 0) { t.stall = 0; } else if (r.note.indexOf('Non eseguita') !== 0) { t.stall++; }
          if (r.status === 'partial') {
            if (t.stall >= 3) { t.stalled = true; } else { pending.push(r.key); }
          }
        });
      }
      var anyStalled = Object.keys(totals).some(function (k) { return totals[k].stalled; });
      if (stopped) { render(totals, 'Interrotto. Puoi riprendere in qualsiasi momento.', false); }
      else if (anyStalled) { render(totals, 'Alcune pulizie non fanno progressi: controlla le note e riprova, oppure usa il cron.', true); }
      else if (pending.length) { render(totals, 'Fermato dopo troppi passi: premi di nuovo per continuare.', true); }
      else { render(totals, 'Pulizia completata. Rilancia la scansione demo per verificare.', false); }
    } catch (e) {
      render(totals, 'Errore: ' + e.message + ' Puoi usare il cron o riprovare.', true);
    } finally {
      btn.disabled = false;
      stopBtn.style.display = 'none';
    }
  });
})();
</script>
{/literal}
{/if}

<div class="card mt-3">
  <h3 class="card-header"><i class="icon-time"></i> Esecuzione automatica (cron)</h3>
  <div class="card-body">
    <p>Il cron esegue le pulizie selezionate e salvate sopra. Il token funge da password, non condividerlo.</p>
    <p><strong>Demo:</strong><br><code>{$cron_demo|escape:'html':'UTF-8'}</code></p>
    <p><strong>Pulizia:</strong><br><code>{$cron_delete|escape:'html':'UTF-8'}</code></p>
    <p class="text-muted">Esempio crontab (ogni domenica alle 3:00): <code>0 3 * * 0 curl -s "URL"</code></p>
    <form method="post" action="{$form_action|escape:'html':'UTF-8'}">
      <button type="submit" name="submitCuiToken" value="1" class="btn btn-default">
        <i class="icon-refresh"></i> Rigenera token
      </button>
    </form>
  </div>
</div>
