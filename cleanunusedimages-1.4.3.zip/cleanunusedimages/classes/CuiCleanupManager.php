<?php
/**
 * Elenco delle pulizie disponibili, impostazioni salvate ed esecuzione.
 *
 * L'ordine in definitions() e' anche l'ordine di esecuzione
 * (es. le connessioni vengono pulite prima degli ospiti).
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CuiCleanupManager
{
    const CFG_SETTINGS = 'CUI_SETTINGS';

    /**
     * @return array<string,array>
     */
    public static function definitions()
    {
        return [
            // Residui di elementi eliminati: vanno per primi, cosi' i file delle righe rimosse dal database
            // vengono trovati come "senza record" dalla pulizia delle immagini prodotto nella stessa esecuzione.
            'db_orphan_products' => [
                'group' => 'orphans', 'risk' => 'medium', 'default' => false,
                'label' => 'Dati di prodotti eliminati (righe orfane nel database)',
                'desc' => 'Righe rimaste in tabelle come image, category_product, feature_product, stock_available, cart_product, customization (solo di carrelli senza ordine), product_lang, combinazioni... che puntano a prodotti non piu\' esistenti. Rimuove anche i record delle loro immagini: i file vengono poi eliminati da "Immagini prodotto inutilizzate" (selezionala, e\' eseguita subito dopo). Fai un backup prima.',
                'param' => null,
            ],
            'img_entities' => [
                'group' => 'orphans', 'risk' => 'low', 'default' => false,
                'label' => 'Immagini di categorie, marchi, fornitori e negozi eliminati',
                'desc' => 'File in img/c, img/m, img/su e img/st (e relative miniature) il cui elemento non esiste piu\' nel database. Le immagini predefinite delle lingue non vengono toccate.',
                'param' => null,
            ],
            'orphan_images' => [
                'group' => 'files', 'risk' => 'low', 'default' => true,
                'label' => 'Immagini prodotto inutilizzate (img/p)',
                'desc' => 'File senza record nel database (residui di importazioni fallite) e miniature di tipi immagine non piu\' configurati. Restano esclusi i file modificati nelle ultime 24 ore.',
                'param' => null,
            ],
            'img_tmp' => [
                'group' => 'files', 'risk' => 'low', 'default' => true,
                'label' => 'Immagini temporanee (img/tmp)',
                'desc' => 'Anteprime temporanee generate dal back office, ricreate automaticamente quando servono.',
                'param' => 24, 'unit' => 'ore', 'min' => 0, 'max' => 8760,
                'param_label' => 'piu\' vecchie di',
            ],
            'log_files' => [
                'group' => 'files', 'risk' => 'low', 'default' => true,
                'label' => 'File di log (var/logs)',
                'desc' => 'File .log di PrestaShop e PHP piu\' vecchi del periodo indicato. Utili solo per la diagnostica.',
                'param' => 30, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchi di',
            ],
            'upload_files' => [
                'group' => 'files', 'risk' => 'medium', 'default' => false,
                'label' => 'File dei clienti non piu\' usati (upload)',
                'desc' => 'File caricati dai clienti per prodotti personalizzabili che non risultano collegati ad alcuna personalizzazione. Quelli di ordini e carrelli con personalizzazioni restano. Minimo 1 giorno.',
                'param' => 30, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchi di',
            ],
            'import_export' => [
                'group' => 'files', 'risk' => 'medium', 'default' => false,
                'label' => 'File di importazione ed esportazione (back office)',
                'desc' => 'Vecchi .csv/.xls/.xlsx caricati o generati da Parametri avanzati > Importa/Esporta. Se riusi un file di importazione tienilo altrove. Minimo 1 giorno.',
                'param' => 30, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchi di',
            ],
            'error_logs' => [
                'group' => 'files', 'risk' => 'low', 'default' => false,
                'label' => 'File error_log del server',
                'desc' => 'File error_log / php_errorlog creati da PHP nelle cartelle del negozio (spesso molto grandi). Il server li ricrea se serve. Con 0 giorni vengono eliminati tutti.',
                'param' => 7, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'non modificati da',
            ],
            'smarty_cache' => [
                'group' => 'files', 'risk' => 'low', 'default' => false,
                'label' => 'Cache Smarty e CSS/JS combinati',
                'desc' => 'Usa le funzioni ufficiali di PrestaShop (come "Svuota la cache" in Parametri avanzati > Prestazioni). Si rigenera da sola: le prime pagine visitate saranno piu\' lente.',
                'param' => null,
            ],
            'db_log' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Log di PrestaShop (tabella log)',
                'desc' => 'Voci del registro eventi del back office piu\' vecchie del periodo indicato (consigliato dalla guida ufficiale).',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchie di',
            ],
            'db_connections' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Statistiche visite (connections)',
                'desc' => 'Connessioni dei visitatori, pagine viste e sorgenti di traffico vecchie (consigliato dalla guida ufficiale). Le statistiche storiche di visite nel back office si azzerano per quel periodo.',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchie di',
            ],
            'db_stats_orphans' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Statistiche orfane (pagine, sorgenti e cache referrer)',
                'desc' => 'Righe di connections_page, connections_source e referrer_cache che puntano a connessioni non piu\' esistenti. Da eseguire dopo la pulizia delle connessioni.',
                'param' => null,
            ],
            'db_page_viewed' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Contatori pagine viste (page_viewed)',
                'desc' => 'Contatori giornalieri delle pagine viste del modulo statistiche, con i relativi periodi (date_range). Si azzerano solo le statistiche del periodo eliminato.',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchi di',
            ],
            'db_pagenotfound' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Errori 404 registrati (pagenotfound)',
                'desc' => 'Elenco delle pagine non trovate raccolto dal modulo statistiche.',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchi di',
            ],
            'db_statssearch' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Statistiche di ricerca (statssearch)',
                'desc' => 'Parole cercate dai visitatori nel negozio.',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchie di',
            ],
            'db_mail' => [
                'group' => 'db', 'risk' => 'low', 'default' => true,
                'label' => 'Registro email inviate (mail)',
                'desc' => 'Solo il registro in Parametri avanzati > E-mail: le email gia\' inviate non vengono toccate.',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'piu\' vecchie di',
            ],
            'db_expired_prices' => [
                'group' => 'db', 'risk' => 'medium', 'default' => false,
                'label' => 'Prezzi specifici scaduti',
                'desc' => 'Promozioni e prezzi per cliente/gruppo con data di fine gia\' passata. Perdi lo storico delle vecchie promozioni.',
                'param' => null,
            ],
            'db_guests' => [
                'group' => 'db', 'risk' => 'medium', 'default' => false,
                'label' => 'Ospiti senza attivita\' (guest)',
                'desc' => 'Visitatori anonimi senza cliente, carrello o connessioni. Da eseguire dopo la pulizia delle connessioni. Alcuni moduli di terze parti usano questi id: valuta con attenzione.',
                'param' => null,
            ],
            'db_carts' => [
                'group' => 'db', 'risk' => 'medium', 'default' => false,
                'label' => 'Carrelli abbandonati',
                'desc' => 'Carrelli mai trasformati in ordine, senza personalizzazioni, messaggi o prezzi specifici, e righe prodotto orfane. Non usare se hai moduli di recupero carrelli che ti servono. Anche con 0 giorni restano i carrelli aggiornati nell\'ultima ora (clienti che stanno acquistando).',
                'param' => 90, 'unit' => 'giorni', 'min' => 0, 'max' => 3650,
                'param_label' => 'non modificati da',
            ],
        ];
    }

    public static function groupLabels()
    {
        return [
            'orphans' => 'Residui di prodotti ed elementi eliminati',
            'files' => 'File e cache',
            'db' => 'Database (statistiche, log, carrelli)',
        ];
    }

    public static function riskLabel($risk)
    {
        return $risk === 'low' ? 'Sicura' : 'Valuta con attenzione';
    }

    // ---------------------------------------------------------------- impostazioni

    /**
     * @return array{tasks:string[],params:array<string,int>,optimize:bool}
     */
    public static function loadSettings()
    {
        $raw = Configuration::getGlobalValue(self::CFG_SETTINGS);
        $data = $raw ? json_decode((string) $raw, true) : null;

        return self::normalizeSettings(is_array($data) ? $data : null);
    }

    public static function saveSettings(array $settings)
    {
        return Configuration::updateGlobalValue(self::CFG_SETTINGS, json_encode($settings));
    }

    /**
     * @param array|null $data null = valori predefiniti
     */
    public static function normalizeSettings($data)
    {
        $defs = self::definitions();
        $selected = ($data !== null && isset($data['tasks']) && is_array($data['tasks'])) ? $data['tasks'] : [];

        $tasks = [];
        foreach ($defs as $key => $def) {
            if ($data === null ? $def['default'] : in_array($key, $selected, true)) {
                $tasks[] = $key;
            }
        }

        $params = [];
        foreach ($defs as $key => $def) {
            if ($def['param'] === null) {
                continue;
            }
            // Campo vuoto, non numerico o negativo = valore predefinito: 0 (= elimina tutto fino a ora)
            // deve essere sempre una scelta esplicita, mai l'effetto di un campo lasciato in bianco.
            $raw = isset($data['params'][$key]) ? $data['params'][$key] : null;
            if (is_numeric($raw) && (int) $raw >= $def['min']) {
                $value = (int) $raw;
            } else {
                $value = $def['param'];
            }
            $params[$key] = min($def['max'], $value);
        }

        return ['tasks' => $tasks, 'params' => $params, 'optimize' => !empty($data['optimize'])];
    }

    public static function settingsFromRequest()
    {
        $tasks = Tools::getValue('cui_tasks');
        $params = Tools::getValue('cui_params');

        return self::normalizeSettings([
            'tasks' => is_array($tasks) ? $tasks : [],
            'params' => is_array($params) ? $params : [],
            'optimize' => (bool) Tools::getValue('cui_optimize'),
        ]);
    }

    // ---------------------------------------------------------------- esecuzione

    public static function emptyResult()
    {
        return [
            'status' => 'ok', 'count' => 0, 'bytes' => null, 'deleted' => 0, 'freed' => null,
            'failed' => 0, 'samples' => [], 'note' => '', 'tables' => [], 'partial' => false,
        ];
    }

    /** @var float|null istante (microtime) oltre il quale le operazioni si fermano */
    private static $deadline = null;

    /**
     * Imposta un limite di tempo per l'esecuzione corrente (null = nessun limite, usato dal cron).
     * Serve nel back office: PrestaShop 9 tiene aperta una seconda connessione al database che, se resta
     * inattiva troppo a lungo, viene chiusa dal server ("MySQL server has gone away").
     */
    public static function setTimeBudget($seconds)
    {
        self::$deadline = ($seconds !== null && $seconds > 0) ? microtime(true) + $seconds : null;
    }

    public static function timeUp()
    {
        return self::$deadline !== null && microtime(true) >= self::$deadline;
    }

    /**
     * @param array      $settings   risultato di normalizeSettings()
     * @param bool       $doDelete   false = demo
     * @param float|null $timeBudget secondi disponibili (null = illimitato, ottimizzazione tabelle consentita)
     *
     * @return array{results:array<string,array>,optimized:string[]}
     */
    public static function run(array $settings, $doDelete, $timeBudget = null)
    {
        @set_time_limit(0);

        // Una sola pulizia alla volta (cron sovrapposti o doppio clic): il blocco cade da solo se la connessione si chiude.
        if (!(int) Db::getInstance()->getValue('SELECT GET_LOCK(\'' . pSQL(_DB_PREFIX_ . 'cui_run') . '\', 0)', false)) {
            throw new RuntimeException('Un\'altra pulizia e\' gia\' in corso: riprova tra qualche minuto.');
        }
        try {
            return self::runLocked($settings, $doDelete, $timeBudget);
        } finally {
            self::setTimeBudget(null);
            Db::getInstance()->getValue('SELECT RELEASE_LOCK(\'' . pSQL(_DB_PREFIX_ . 'cui_run') . '\')', false);
        }
    }

    private static function runLocked(array $settings, $doDelete, $timeBudget)
    {
        self::setTimeBudget($timeBudget);

        $results = [];
        $tables = [];
        foreach (array_keys(self::definitions()) as $key) {
            if (!in_array($key, $settings['tasks'], true)) {
                continue;
            }
            if (self::timeUp()) {
                $skipped = self::emptyResult();
                $skipped['status'] = 'partial';
                $skipped['note'] = 'Non eseguita: limite di tempo raggiunto. Premi di nuovo il pulsante per continuare '
                    . '(oppure usa il cron, che non ha limite di tempo).';
                $results[$key] = $skipped;
                continue;
            }

            $param = isset($settings['params'][$key]) ? $settings['params'][$key] : null;
            try {
                $r = self::runTask($key, $param, $doDelete);
            } catch (Exception $e) {
                $r = self::emptyResult();
                $r['status'] = 'error';
                $r['note'] = $e->getMessage();
            }
            if ($doDelete && $r['status'] === 'ok'
                && (!empty($r['partial']) || ($r['count'] > 0 && $r['deleted'] + $r['failed'] < $r['count']))) {
                $r['status'] = 'partial';
                if (stripos($r['note'], 'rimangono') === false && stripos($r['note'], 'rilancia') === false) {
                    $r['note'] = trim($r['note'] . ' Pulizia interrotta o incompleta: rilanciala per continuare.');
                }
            }
            if ($doDelete && $r['deleted'] > 0) {
                $tables = array_merge($tables, $r['tables']);
            }
            $results[$key] = $r;
        }

        // L'ottimizzazione e' pesante: solo senza limite di tempo (cron).
        $optimized = [];
        if ($doDelete && $timeBudget === null && $settings['optimize'] && !empty($tables)) {
            try {
                $optimized = CuiDbCleaner::optimize($tables);
            } catch (Exception $e) {
                $optimized = [];
            }
        }

        return ['results' => $results, 'optimized' => $optimized];
    }

    private static function runTask($key, $param, $doDelete)
    {
        switch ($key) {
            case 'orphan_images':
                return self::runOrphanImages($doDelete);
            case 'img_tmp':
                // anche con 0 ore restano i file degli ultimi 10 minuti (caricamenti in corso)
                return CuiFileCleaner::run(self::imgDir() . 'tmp', max($param * 3600, 600), null, $doDelete);
            case 'log_files':
                return CuiFileCleaner::run(rtrim(_PS_ROOT_DIR_, '/\\') . '/var/logs', $param * 86400, '/\.log$/i', $doDelete);
            case 'smarty_cache':
                return self::runSmartyCache($doDelete);
            case 'img_entities':
            case 'upload_files':
            case 'import_export':
            case 'error_logs':
                return CuiExtraCleaner::run($key, $param, $doDelete);
        }

        return CuiDbCleaner::run($key, $param, $doDelete);
    }

    private static function imgDir()
    {
        return defined('_PS_IMG_DIR_') ? rtrim(_PS_IMG_DIR_, '/\\') . '/' : rtrim(_PS_ROOT_DIR_, '/\\') . '/img/';
    }

    private static function runOrphanImages($doDelete)
    {
        $res = self::emptyResult();
        $r = CuiImageCleaner::createDefault()->execute($doDelete);

        $res['count'] = count($r['items']);
        $res['bytes'] = $r['bytes'];
        $res['deleted'] = $r['deleted'];
        $res['freed'] = $r['freed'];
        $res['failed'] = count($r['failed']);

        $labels = [
            CuiImageCleaner::REASON_ORPHAN => 'senza record nel database',
            CuiImageCleaner::REASON_TYPE => 'tipo immagine non piu\' configurato',
        ];
        foreach (array_slice($r['items'], 0, 20) as $item) {
            $res['samples'][] = 'img/p/' . $item['rel'] . ' (' . $labels[$item['reason']] . ')';
        }

        $notes = [sprintf('Orfani: %d, miniature obsolete: %d.', $r['orphans'], $r['obsolete'])];
        if (!empty($r['recent'])) {
            $notes[] = sprintf(
                'Rimandati %d file modificati nelle ultime 24 ore (protezione per importazioni in corso): '
                . 'verranno valutati alla prossima esecuzione.',
                $r['recent']
            );
        }
        if (!$r['types_checked']) {
            $notes[] = 'Nessun tipo immagine prodotto configurato: miniature obsolete non controllate.';
        }
        if ($r['skipped'] > 0) {
            $notes[] = sprintf(
                'Non toccati %d file (nome non riconosciuto: %d, cartella diversa da quella dell\'id: %d).',
                $r['skipped'],
                $r['skipped_detail']['no_match'],
                $r['skipped_detail']['bad_dir']
            );
            $examples = array_merge($r['skipped_samples']['no_match'], $r['skipped_samples']['bad_dir']);
            if (!empty($examples)) {
                $notes[] = 'Esempi: ' . implode(', ', array_slice($examples, 0, 6)) . '.';
            }
        }
        $res['note'] = implode(' ', $notes);

        return $res;
    }

    private static function runSmartyCache($doDelete)
    {
        $res = self::emptyResult();
        if (!defined('_PS_CACHE_DIR_')) {
            $res['status'] = 'skipped';
            $res['note'] = 'Cartella cache non rilevata.';

            return $res;
        }
        $dirs = [_PS_CACHE_DIR_ . 'smarty/cache', _PS_CACHE_DIR_ . 'smarty/compile'];
        $before = CuiFileCleaner::countFiles($dirs);
        $res['count'] = $before['count'];
        $res['bytes'] = $before['bytes'];
        $res['note'] = 'Conta i file di cache e compilazione Smarty; la pulizia include anche CSS/JS combinati.';

        if ($doDelete) {
            if (method_exists('Tools', 'clearSmartyCache')) {
                Tools::clearSmartyCache();
            }
            if (method_exists('Media', 'clearCache')) {
                Media::clearCache();
            }
            $after = CuiFileCleaner::countFiles($dirs);
            $res['deleted'] = max(0, $before['count'] - $after['count']);
            $res['freed'] = max(0, $before['bytes'] - $after['bytes']);
        }

        return $res;
    }
}
