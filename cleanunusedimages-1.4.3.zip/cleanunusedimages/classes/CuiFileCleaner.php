<?php
/**
 * Pulizia di file vecchi in una cartella (img/tmp, var/logs) e conteggio della cache Smarty.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CuiFileCleaner
{
    /**
     * Elimina (o elenca, in demo) i file piu' vecchi di $maxAgeSeconds.
     *
     * @param string      $dir           cartella da pulire
     * @param int         $maxAgeSeconds eta' minima in secondi (data di ultima modifica)
     * @param string|null $namePattern   regex sul nome del file, null = tutti
     * @param bool        $doDelete
     *
     * @return array risultato nel formato di CuiCleanupManager::emptyResult()
     */
    public static function run($dir, $maxAgeSeconds, $namePattern, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        $res['freed'] = 0;

        $base = rtrim(str_replace('\\', '/', (string) $dir), '/');
        if (!is_dir($base)) {
            $res['status'] = 'skipped';
            $res['note'] = 'Cartella non trovata: ' . $base;

            return $res;
        }

        $limit = time() - (int) $maxAgeSeconds;
        $items = [];
        $bytes = 0;

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS)
        );
        foreach ($iterator as $file) {
            /** @var SplFileInfo $file */
            if ($file->isLink() || !$file->isFile()) {
                continue;
            }
            $name = $file->getFilename();
            if (in_array(strtolower($name), CuiImageCleaner::IGNORED_FILES, true)) {
                continue;
            }
            if ($namePattern !== null && !preg_match($namePattern, $name)) {
                continue;
            }
            if ($file->getMTime() > $limit) {
                continue;
            }
            $size = (int) $file->getSize();
            $items[] = ['rel' => substr($file->getPathname(), strlen($base) + 1), 'size' => $size, 'reason' => 'old'];
            $bytes += $size;
        }

        $res['count'] = count($items);
        $res['bytes'] = $bytes;
        foreach (array_slice($items, 0, 20) as $item) {
            $res['samples'][] = $item['rel'];
        }

        if ($doDelete && !empty($items)) {
            $del = (new CuiImageCleaner($base))->delete($items);
            $res['deleted'] = $del['deleted'];
            $res['freed'] = $del['freed'];
            $res['failed'] = count($del['failed']);
        }

        return $res;
    }

    /**
     * Conta i file (escluso index.php) sotto le cartelle indicate.
     *
     * @param string[] $dirs
     *
     * @return array{count:int, bytes:int}
     */
    public static function countFiles(array $dirs)
    {
        $count = 0;
        $bytes = 0;
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                continue;
            }
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
            );
            foreach ($iterator as $file) {
                if ($file->isFile() && !in_array(strtolower($file->getFilename()), CuiImageCleaner::IGNORED_FILES, true)) {
                    ++$count;
                    $bytes += (int) $file->getSize();
                }
            }
        }

        return ['count' => $count, 'bytes' => $bytes];
    }
}
