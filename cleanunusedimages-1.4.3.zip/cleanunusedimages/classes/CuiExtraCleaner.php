<?php
/**
 * Pulizie di file aggiuntive:
 *  - immagini rimaste di categorie, marchi, fornitori e negozi eliminati (img/c, img/m, img/su, img/st);
 *  - file caricati dai clienti per personalizzazioni (upload/) non piu' collegati a nessuna personalizzazione;
 *  - vecchi file CSV/Excel di importazione ed esportazione del back office;
 *  - file error_log / php_errorlog creati dal server (spesso enormi).
 *
 * Tutte le eliminazioni passano da CuiImageCleaner::delete(): mai fuori dalla cartella prevista,
 * mai collegamenti simbolici, cartelle rimaste vuote rimosse.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CuiExtraCleaner
{
    const IMAGE_REGEX = '/^(\d+)(?:[-_].+)?\.(?:jpe?g|png|gif|webp|avif)$/i';
    const SAMPLES = 20;

    /** sottocartella di img => [tabella senza prefisso, colonna id] */
    private static $entities = [
        'c' => ['category', 'id_category'],
        'm' => ['manufacturer', 'id_manufacturer'],
        'su' => ['supplier', 'id_supplier'],
        'st' => ['store', 'id_store'],
    ];

    /**
     * @param string   $key
     * @param int|null $days
     * @param bool     $doDelete
     *
     * @return array
     */
    public static function run($key, $days, $doDelete)
    {
        switch ($key) {
            case 'img_entities':
                return self::runEntityImages($doDelete);
            case 'upload_files':
                // minimo 1 giorno: i file appena caricati possono non essere ancora collegati al carrello
                return self::runUploads(max((int) $days * 86400, 86400), $doDelete);
            case 'import_export':
                return self::runImportExport(max((int) $days * 86400, 86400), $doDelete);
            case 'error_logs':
                return self::runErrorLogs((int) $days * 86400, $doDelete);
        }

        throw new RuntimeException('Pulizia sconosciuta: ' . $key);
    }

    // ---------------------------------------------------------------- immagini di categorie, marchi...

    private static function runEntityImages($doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        $res['freed'] = 0;
        $byBase = [];
        $notes = [];
        $checked = 0;

        foreach (self::$entities as $sub => $def) {
            $dir = self::imgDir() . $sub;
            if (!is_dir($dir) || !self::tableExists($def[0])) {
                continue;
            }
            // Se la tabella e' vuota (errore di prefisso, importazione in corso...) non si tocca nulla.
            if ((int) Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . $def[0] . '`', false) === 0) {
                $notes[] = 'img/' . $sub . ': tabella ' . _DB_PREFIX_ . $def[0] . ' vuota, saltata per sicurezza.';
                continue;
            }
            ++$checked;

            $candidates = []; // id => [file...]
            foreach ((array) scandir($dir) as $name) {
                $path = $dir . '/' . $name;
                if ($name === '.' || $name === '..' || is_link($path) || !is_file($path)) {
                    continue;
                }
                // "1-default-..." / "it-default-..." sono le immagini predefinite di lingua, non di un elemento
                if (!preg_match(self::IMAGE_REGEX, $name, $m) || preg_match('/^\d+-default-/i', $name)) {
                    continue;
                }
                $candidates[(int) $m[1]][] = $name;
            }

            $existing = [];
            foreach (array_chunk(array_keys($candidates), 1000) as $chunk) {
                $rows = Db::getInstance()->executeS(
                    'SELECT `' . $def[1] . '` FROM `' . _DB_PREFIX_ . $def[0] . '` WHERE `' . $def[1]
                    . '` IN (' . implode(',', array_map('intval', $chunk)) . ')',
                    true,
                    false
                );
                foreach ((array) $rows as $row) {
                    $existing[(int) reset($row)] = true;
                }
            }

            foreach ($candidates as $id => $files) {
                if (isset($existing[$id])) {
                    continue;
                }
                foreach ($files as $name) {
                    $byBase[$dir][] = ['rel' => $name, 'size' => (int) @filesize($dir . '/' . $name), 'show' => 'img/' . $sub . '/' . $name];
                }
            }
        }

        if ($checked === 0) {
            $res['status'] = 'skipped';
            $res['note'] = trim(implode(' ', $notes) . ' Nessuna cartella da controllare.');

            return $res;
        }
        $res['note'] = trim(implode(' ', $notes) . ' Solo file di categorie, marchi, fornitori e negozi che non esistono piu\' nel database.');

        return self::finish($res, $byBase, $doDelete);
    }

    // ---------------------------------------------------------------- upload personalizzazioni

    private static function runUploads($maxAge, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        $res['freed'] = 0;
        $dir = rtrim(defined('_PS_UPLOAD_DIR_') ? _PS_UPLOAD_DIR_ : rtrim(_PS_ROOT_DIR_, '/\\') . '/upload', '/\\');
        if (!is_dir($dir)) {
            $res['status'] = 'skipped';
            $res['note'] = 'Cartella upload non trovata.';

            return $res;
        }
        if (!self::tableExists('customized_data')) {
            $res['status'] = 'skipped';
            $res['note'] = 'Tabella ' . _DB_PREFIX_ . 'customized_data non presente.';

            return $res;
        }

        $limit = time() - $maxAge;
        $byHash = []; // hash => [file...]
        foreach ((array) scandir($dir) as $name) {
            $path = $dir . '/' . $name;
            if (is_link($path) || !is_file($path) || !preg_match('/^([a-f0-9]{32})(_small)?$/i', $name, $m)) {
                continue; // solo i nomi generati da PrestaShop per i file dei clienti
            }
            if (@filemtime($path) > $limit) {
                continue;
            }
            $byHash[strtolower($m[1])][] = $name;
        }

        $used = [];
        foreach (array_chunk(array_keys($byHash), 500) as $chunk) {
            $in = "'" . implode("','", array_map('pSQL', $chunk)) . "'";
            $rows = Db::getInstance()->executeS(
                'SELECT `value` FROM `' . _DB_PREFIX_ . 'customized_data` WHERE `value` IN (' . $in . ')',
                true,
                false
            );
            foreach ((array) $rows as $row) {
                $used[strtolower((string) $row['value'])] = true;
            }
        }

        $items = [];
        foreach ($byHash as $hash => $files) {
            if (isset($used[$hash])) {
                continue;
            }
            foreach ($files as $name) {
                $items[] = ['rel' => $name, 'size' => (int) @filesize($dir . '/' . $name), 'show' => 'upload/' . $name];
            }
        }
        $res['note'] = 'Solo file di clienti non piu\' collegati ad alcuna personalizzazione.';

        return self::finish($res, [$dir => $items], $doDelete);
    }

    // ---------------------------------------------------------------- import / export

    private static function runImportExport($maxAge, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        $res['freed'] = 0;
        $found = 0;

        foreach (self::adminDirs() as $admin) {
            foreach (['import', 'export'] as $sub) {
                if (!is_dir($admin . '/' . $sub)) {
                    continue;
                }
                ++$found;
                $r = CuiFileCleaner::run($admin . '/' . $sub, $maxAge, '/\.(csv|xls|xlsx|ods)$/i', $doDelete);
                self::merge($res, $r, basename($admin) . '/' . $sub . '/');
            }
        }
        if ($found === 0) {
            $res['status'] = 'skipped';
            $res['note'] = 'Cartella di amministrazione (import/export) non trovata.';

            return $res;
        }
        $res['note'] = 'Solo file .csv/.xls/.xlsx/.ods nelle cartelle import ed export del back office. I backup non vengono toccati.';

        return $res;
    }

    // ---------------------------------------------------------------- error_log

    private static function runErrorLogs($maxAge, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        $res['freed'] = 0;
        $limit = time() - $maxAge;
        $root = rtrim(str_replace('\\', '/', _PS_ROOT_DIR_), '/');

        $dirs = [$root];
        $skip = ['img', 'var', 'vendor', 'upload', 'download', 'translations', 'cache', 'docs', 'mails', 'node_modules', 'js', 'css', 'config'];
        foreach ((array) glob($root . '/*', GLOB_ONLYDIR) as $d) {
            if (!in_array(basename($d), $skip, true) && !is_link($d)) {
                $dirs[] = $d;
            }
        }
        foreach (['modules', 'themes'] as $parent) {
            foreach ((array) glob($root . '/' . $parent . '/*', GLOB_ONLYDIR) as $d) {
                if (!is_link($d)) {
                    $dirs[] = $d;
                }
            }
        }

        $byBase = [];
        foreach (array_unique($dirs) as $d) {
            foreach (['error_log', 'php_errorlog'] as $name) {
                $path = $d . '/' . $name;
                if (is_file($path) && !is_link($path) && @filemtime($path) <= $limit) {
                    $byBase[$d][] = ['rel' => $name, 'size' => (int) @filesize($path), 'show' => substr($path, strlen($root) + 1)];
                }
            }
        }
        $res['note'] = 'File error_log e php_errorlog di PrestaShop, moduli e temi: il server li ricrea da solo se serve.';

        return self::finish($res, $byBase, $doDelete);
    }

    // ---------------------------------------------------------------- utilita'

    /**
     * @param array<string,array> $byBase cartella => elenco file [rel,size,show]
     */
    private static function finish(array $res, array $byBase, $doDelete)
    {
        $all = [];
        foreach ($byBase as $items) {
            $all = array_merge($all, $items);
        }
        $res['count'] = count($all);
        $res['bytes'] = array_sum(array_column($all, 'size'));
        foreach (array_slice($all, 0, self::SAMPLES) as $item) {
            $res['samples'][] = $item['show'];
        }

        if ($doDelete) {
            foreach ($byBase as $base => $items) {
                if (empty($items)) {
                    continue;
                }
                $del = (new CuiImageCleaner($base))->delete($items);
                $res['deleted'] += $del['deleted'];
                $res['freed'] += $del['freed'];
                $res['failed'] += count($del['failed']);
            }
        }

        return $res;
    }

    private static function merge(array &$res, array $r, $prefix)
    {
        if ($r['status'] === 'skipped') {
            return;
        }
        foreach (['count', 'deleted', 'failed'] as $k) {
            $res[$k] += (int) $r[$k];
        }
        $res['bytes'] = (int) $res['bytes'] + (int) $r['bytes'];
        $res['freed'] = (int) $res['freed'] + (int) $r['freed'];
        foreach ($r['samples'] as $s) {
            if (count($res['samples']) < self::SAMPLES) {
                $res['samples'][] = $prefix . $s;
            }
        }
    }

    /**
     * Cartelle di amministrazione: quelle con "themes" e almeno una tra "import" ed "export".
     *
     * @return string[]
     */
    private static function adminDirs()
    {
        $dirs = [];
        if (defined('_PS_ADMIN_DIR_')) {
            $dirs[] = rtrim(str_replace('\\', '/', _PS_ADMIN_DIR_), '/');
        }
        $root = rtrim(str_replace('\\', '/', _PS_ROOT_DIR_), '/');
        foreach ((array) glob($root . '/*', GLOB_ONLYDIR) as $d) {
            if (!is_link($d) && is_dir($d . '/themes') && (is_dir($d . '/import') || is_dir($d . '/export'))) {
                $dirs[] = $d;
            }
        }

        return array_values(array_unique($dirs));
    }

    private static function imgDir()
    {
        return defined('_PS_IMG_DIR_') ? rtrim(str_replace('\\', '/', _PS_IMG_DIR_), '/') . '/' : rtrim(str_replace('\\', '/', _PS_ROOT_DIR_), '/') . '/img/';
    }

    private static function tableExists($table)
    {
        return (bool) Db::getInstance()->getValue(
            'SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \''
            . pSQL(_DB_PREFIX_ . $table) . '\'',
            false
        );
    }
}
