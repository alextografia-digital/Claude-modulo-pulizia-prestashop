<?php
/**
 * Scansione e pulizia delle immagini prodotto inutilizzate (img/p).
 *
 * Una immagine viene considerata inutilizzata se:
 *  - il file (originale o miniatura) appartiene a un id_image che non esiste piu' nel database;
 *  - e' una miniatura il cui tipo immagine non e' piu' configurato per i prodotti.
 *
 * Protezione: i file modificati nelle ultime 24 ore non vengono mai toccati. Alcune importazioni
 * scrivono il file prima di registrarlo nel database e una pulizia eseguita in quel momento
 * lo considererebbe orfano.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CuiImageCleaner
{
    const REASON_ORPHAN = 'orphan';
    const REASON_TYPE = 'obsolete_type';

    /** Eta' minima (secondi) di un file prima che possa essere eliminato: 24 ore. */
    const MIN_AGE = 86400;

    /** File di servizio mai toccati. */
    const IGNORED_FILES = ['index.php', '.htaccess', '.gitignore', '.gitkeep', '.ds_store', 'thumbs.db'];

    /** @var string cartella base senza slash finale, con separatori "/" */
    private $baseDir;

    /**
     * @param string $baseDir cartella delle immagini prodotto (es. _PS_PROD_IMG_DIR_)
     */
    public function __construct($baseDir)
    {
        $this->baseDir = rtrim(str_replace('\\', '/', (string) $baseDir), '/');
    }

    public static function createDefault()
    {
        // _PS_PROD_IMG_DIR_ non esiste piu' in PrestaShop 9: si parte da _PS_IMG_DIR_ (o dalla root).
        if (defined('_PS_PROD_IMG_DIR_')) {
            $dir = _PS_PROD_IMG_DIR_;
        } elseif (defined('_PS_IMG_DIR_')) {
            $dir = rtrim(_PS_IMG_DIR_, '/\\') . '/p/';
        } else {
            $dir = rtrim(_PS_ROOT_DIR_, '/\\') . '/img/p/';
        }

        return new self($dir);
    }

    /**
     * Tutti gli id_image presenti nel database (tabella globale, valida per ogni negozio).
     *
     * @return array<int,bool> id => true
     */
    public static function loadImageIds()
    {
        $ids = [];
        $db = Db::getInstance();
        $res = $db->query('SELECT `id_image` FROM `' . _DB_PREFIX_ . 'image`');
        if ($res) {
            while ($row = $db->nextRow($res)) {
                $ids[(int) $row['id_image']] = true;
            }
        }

        return $ids;
    }

    /**
     * Nomi dei tipi immagine attivi per i prodotti.
     *
     * @return string[]
     */
    public static function loadProductTypeNames()
    {
        $names = [];
        $rows = Db::getInstance()->executeS(
            'SELECT `name` FROM `' . _DB_PREFIX_ . 'image_type` WHERE `products` = 1'
        );
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $names[] = (string) $row['name'];
            }
        }

        return $names;
    }

    /**
     * Cerca i file da eliminare senza modificare nulla.
     *
     * @param array<int,bool> $validIds  id_image presenti nel database
     * @param string[]        $typeNames tipi immagine prodotto configurati
     *
     * @return array{items: array<int,array{rel:string,size:int,reason:string}>, orphans:int, obsolete:int, bytes:int, scanned:int, skipped:int}
     *
     * @throws RuntimeException
     */
    public function scan(array $validIds, array $typeNames)
    {
        if (!is_dir($this->baseDir)) {
            throw new RuntimeException('Cartella immagini non trovata: ' . $this->baseDir);
        }
        // Protezione: con la tabella vuota ogni file risulterebbe "orfano".
        if (empty($validIds)) {
            throw new RuntimeException(
                'La tabella delle immagini prodotto e\' vuota: operazione annullata per sicurezza '
                . '(tutti i file risulterebbero inutilizzati).'
            );
        }

        $types = array_flip($typeNames);
        $checkTypes = !empty($typeNames);

        $result = [
            'items' => [], 'orphans' => 0, 'obsolete' => 0, 'bytes' => 0, 'scanned' => 0, 'skipped' => 0,
            // file da eliminare ma modificati da meno di MIN_AGE secondi: rimandati alla prossima esecuzione
            'recent' => 0,
            // dettaglio dei file non toccati: nome non riconosciuto / cartella non corrispondente all'id
            'skipped_detail' => ['no_match' => 0, 'bad_dir' => 0],
            'skipped_samples' => ['no_match' => [], 'bad_dir' => []],
        ];

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $this->baseDir,
                FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS
            )
        );

        foreach ($iterator as $file) {
            /** @var SplFileInfo $file */
            if ($file->isLink() || !$file->isFile()) {
                continue;
            }
            $name = $file->getFilename();
            if (in_array(strtolower($name), self::IGNORED_FILES, true)) {
                continue;
            }
            ++$result['scanned'];

            // <id>[-<tipo>][@2x].<estensione>
            $rel = substr($file->getPathname(), strlen($this->baseDir) + 1);
            if (!preg_match('/^(\d+)(?:-(.+?))?(?:@2x)?\.(?:jpe?g|png|gif|webp|avif)$/i', $name, $m)) {
                $this->noteSkipped($result, 'no_match', $rel);
                continue;
            }
            $digits = $m[1];
            $id = (int) $digits;
            if ($id < 1 || (string) $id !== $digits) {
                $this->noteSkipped($result, 'no_match', $rel);
                continue;
            }

            // Il file deve trovarsi nella cartella attesa (1/2/3/123.jpg), altrimenti non lo tocchiamo.
            if (dirname($rel) !== implode('/', str_split($digits))) {
                $this->noteSkipped($result, 'bad_dir', $rel);
                continue;
            }

            $type = (isset($m[2]) && $m[2] !== '') ? $m[2] : null;

            $reason = null;
            if (!isset($validIds[$id])) {
                $reason = self::REASON_ORPHAN;
            } elseif ($type !== null && $checkTypes && !isset($types[$type])) {
                $reason = self::REASON_TYPE;
            }
            if ($reason === null) {
                continue;
            }
            // Mai eliminare file recenti: potrebbero essere in fase di importazione.
            if ((int) $file->getMTime() > time() - self::MIN_AGE) {
                ++$result['recent'];
                continue;
            }

            $size = (int) $file->getSize();
            $result['items'][] = ['rel' => $rel, 'size' => $size, 'reason' => $reason];
            $result['bytes'] += $size;
            if ($reason === self::REASON_ORPHAN) {
                ++$result['orphans'];
            } else {
                ++$result['obsolete'];
            }
        }

        return $result;
    }

    /**
     * Elimina i file indicati e rimuove le cartelle rimaste vuote.
     *
     * @param array<int,array{rel:string,size:int}> $items
     *
     * @return array{deleted:int, freed:int, failed:string[]}
     */
    public function delete(array $items)
    {
        $out = ['deleted' => 0, 'freed' => 0, 'failed' => []];
        $base = realpath($this->baseDir);
        if ($base === false) {
            return $out;
        }
        $base = rtrim(str_replace('\\', '/', $base), '/');
        $touched = [];

        foreach ($items as $item) {
            if (class_exists('CuiCleanupManager', false) && CuiCleanupManager::timeUp()) {
                break; // i file rimasti verranno eliminati alla prossima esecuzione
            }
            $real = realpath($this->baseDir . '/' . $item['rel']);
            $realNorm = $real === false ? '' : str_replace('\\', '/', $real);
            // Mai uscire dalla cartella base.
            if ($real === false || strpos($realNorm, $base . '/') !== 0) {
                $out['failed'][] = $item['rel'];
                continue;
            }
            if (@unlink($real)) {
                ++$out['deleted'];
                $out['freed'] += (int) $item['size'];
                $touched[dirname($realNorm)] = true;
            } else {
                $out['failed'][] = $item['rel'];
            }
        }

        foreach (array_keys($touched) as $dir) {
            $this->pruneEmptyDirs($dir, $base);
        }

        return $out;
    }

    /**
     * Scansiona e, se richiesto, elimina.
     *
     * @param bool $doDelete false = modalita' demo
     *
     * @return array
     *
     * @throws RuntimeException
     */
    public function execute($doDelete)
    {
        @set_time_limit(0);

        $types = self::loadProductTypeNames();
        $report = $this->scan(self::loadImageIds(), $types);
        $report['mode'] = $doDelete ? 'delete' : 'demo';
        $report['types_checked'] = !empty($types);
        $report['deleted'] = 0;
        $report['freed'] = 0;
        $report['failed'] = [];

        if ($doDelete) {
            $report = array_merge($report, $this->delete($report['items']));
        }

        return $report;
    }

    private function noteSkipped(array &$result, $why, $rel)
    {
        ++$result['skipped'];
        ++$result['skipped_detail'][$why];
        if (count($result['skipped_samples'][$why]) < 8) {
            $result['skipped_samples'][$why][] = $rel;
        }
    }

    /**
     * Risale l'albero eliminando le cartelle che contengono solo index.php.
     */
    private function pruneEmptyDirs($dir, $base)
    {
        while ($dir !== $base && strpos($dir, $base . '/') === 0 && is_dir($dir)) {
            $entries = array_diff(scandir($dir) ?: ['.', '..', '?'], ['.', '..', 'index.php']);
            if (!empty($entries)) {
                return;
            }
            if (is_file($dir . '/index.php')) {
                @unlink($dir . '/index.php');
            }
            if (!@rmdir($dir)) {
                return;
            }
            $dir = str_replace('\\', '/', dirname($dir));
        }
    }
}
