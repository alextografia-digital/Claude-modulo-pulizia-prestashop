<?php
/**
 * Pulizia file e dati inutilizzati - modulo per PrestaShop 8.x / 9.x
 *
 * Pulizie disponibili (tutte selezionabili, con modalita' demo):
 *  - immagini prodotto inutilizzate (img/p), immagini temporanee (img/tmp), log (var/logs), cache Smarty;
 *  - tabelle del database: log, statistiche visite, errori 404, ricerche, registro email,
 *    prezzi specifici scaduti, ospiti senza attivita', carrelli abbandonati;
 *  - esecuzione automatica tramite cron (URL protetto da token);
 *  - compatibile multistore (le tabelle e le impostazioni sono globali).
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/CuiImageCleaner.php';
require_once __DIR__ . '/classes/CuiFileCleaner.php';
require_once __DIR__ . '/classes/CuiDbCleaner.php';
require_once __DIR__ . '/classes/CuiExtraCleaner.php';
require_once __DIR__ . '/classes/CuiCleanupManager.php';

class Cleanunusedimages extends Module
{
    const CFG_TOKEN = 'CUI_CRON_TOKEN';
    const ADMIN_TIME_BUDGET = 20; // secondi per ogni esecuzione dal back office

    public function __construct()
    {
        $this->name = 'cleanunusedimages';
        $this->tab = 'administration';
        $this->version = '1.4.3';
        $this->author = 'Custom';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = 'Pulizia file e dati inutilizzati';
        $this->description = 'Elimina in sicurezza immagini prodotto inutilizzate, file temporanei, log, statistiche '
            . 'e dati vecchi del database per liberare spazio e velocizzare il negozio.';
        $this->confirmUninstall = 'Vuoi davvero disinstallare il modulo?';
    }

    public function install()
    {
        return parent::install()
            && Configuration::updateGlobalValue(self::CFG_TOKEN, $this->generateToken());
    }

    public function uninstall()
    {
        return Configuration::deleteByName(self::CFG_TOKEN)
            && Configuration::deleteByName(CuiCleanupManager::CFG_SETTINGS)
            && Configuration::deleteByName(CuiDbCleaner::CURSOR_GUESTS)
            && parent::uninstall();
    }

    public function getContent()
    {
        $output = '';
        $run = null;
        $mode = null;

        if (Tools::isSubmit('submitCuiToken')) {
            Configuration::updateGlobalValue(self::CFG_TOKEN, $this->generateToken());
            $output .= $this->displayConfirmation('Token del cron rigenerato: aggiorna gli URL gia\' configurati.');
        } elseif (Tools::isSubmit('submitCuiSave') || Tools::isSubmit('submitCuiScan') || Tools::isSubmit('submitCuiDelete')) {
            $settings = CuiCleanupManager::settingsFromRequest();
            CuiCleanupManager::saveSettings($settings);

            if (Tools::isSubmit('submitCuiSave')) {
                $output .= $this->displayConfirmation('Impostazioni salvate (valgono anche per il cron).');
            } elseif (empty($settings['tasks'])) {
                $output .= $this->displayError('Seleziona almeno una pulizia.');
            } elseif (Tools::isSubmit('submitCuiDelete') && !Tools::getValue('cui_confirm')) {
                $output .= $this->displayError('Spunta la casella di conferma per procedere con la pulizia definitiva.');
            } else {
                $doDelete = Tools::isSubmit('submitCuiDelete');
                $mode = $doDelete ? 'delete' : 'demo';
                try {
                    // Limite di tempo: oltre qualche decina di secondi la connessione al database usata
                    // dal back office di PrestaShop 9 puo' essere chiusa dal server. Il cron non ha limiti.
                    $run = CuiCleanupManager::run($settings, $doDelete, self::ADMIN_TIME_BUDGET);
                } catch (Exception $e) {
                    $output .= $this->displayError($e->getMessage());
                }
                if ($doDelete && $run !== null) {
                    $output .= $this->displayConfirmation('Pulizia completata.');
                }
            }
        }

        return $output . $this->renderPage($mode, $run);
    }

    private function renderPage($mode, $run)
    {
        $settings = CuiCleanupManager::loadSettings();
        $defs = CuiCleanupManager::definitions();
        $groupLabels = CuiCleanupManager::groupLabels();

        $groups = [];
        foreach ($defs as $key => $def) {
            if (!isset($groups[$def['group']])) {
                $groups[$def['group']] = ['title' => $groupLabels[$def['group']], 'tasks' => []];
            }
            $groups[$def['group']]['tasks'][] = [
                'key' => $key,
                'label' => $def['label'],
                'desc' => $def['desc'],
                'risk' => $def['risk'],
                'risk_label' => CuiCleanupManager::riskLabel($def['risk']),
                'checked' => in_array($key, $settings['tasks'], true),
                'has_param' => $def['param'] !== null,
                'param' => isset($settings['params'][$key]) ? $settings['params'][$key] : '',
                'param_label' => isset($def['param_label']) ? $def['param_label'] : '',
                'unit' => isset($def['unit']) ? $def['unit'] : '',
            ];
        }

        $view = false;
        if (is_array($run)) {
            $rows = [];
            $totalBytes = 0;
            $totalFreed = 0;
            $hasPartial = false;
            foreach ($run['results'] as $key => $r) {
                if ($r['status'] === 'partial') {
                    $hasPartial = true;
                }
                $totalBytes += (int) $r['bytes'];
                $totalFreed += (int) $r['freed'];
                $rows[] = [
                    'label' => $defs[$key]['label'],
                    'status' => $r['status'],
                    'count' => $r['count'],
                    'size' => $r['bytes'] === null ? '-' : Tools::formatBytes($r['bytes'], 2),
                    'deleted' => $r['deleted'],
                    'freed' => $r['freed'] === null ? '-' : Tools::formatBytes($r['freed'], 2),
                    'failed' => $r['failed'],
                    'note' => $r['note'],
                    'samples' => $r['samples'],
                ];
            }
            $view = [
                'mode' => $mode,
                'has_partial' => $hasPartial,
                'rows' => $rows,
                'total_size' => Tools::formatBytes($totalBytes, 2),
                'total_freed' => Tools::formatBytes($totalFreed, 2),
                'optimized' => $run['optimized'],
            ];
        }

        $token = (string) Configuration::getGlobalValue(self::CFG_TOKEN);

        // URL relativo per l'esecuzione automatica: la pagina lo chiama sullo stesso dominio del back office.
        $jsonParts = parse_url($this->context->link->getModuleLink($this->name, 'cron', ['token' => $token, 'format' => 'json']));
        $cronJson = (isset($jsonParts['path']) ? $jsonParts['path'] : '/')
            . (isset($jsonParts['query']) ? '?' . $jsonParts['query'] : '');

        $this->context->smarty->assign([
            'cron_json' => $cronJson,
            'form_action' => $_SERVER['REQUEST_URI'],
            'groups' => $groups,
            'optimize' => $settings['optimize'],
            'view' => $view,
            'cron_demo' => $this->context->link->getModuleLink($this->name, 'cron', ['token' => $token, 'mode' => 'demo']),
            'cron_delete' => $this->context->link->getModuleLink($this->name, 'cron', ['token' => $token, 'mode' => 'delete']),
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');
    }

    private function generateToken()
    {
        return bin2hex(random_bytes(16));
    }
}
