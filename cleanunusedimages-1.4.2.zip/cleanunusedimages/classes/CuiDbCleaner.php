<?php
/**
 * Pulizie sicure di tabelle del database PrestaShop (statistiche, log, carrelli abbandonati...).
 *
 * Tutte le eliminazioni avvengono a lotti, con condizioni conservative:
 *  - mai carrelli collegati a un ordine;
 *  - mai ospiti collegati a un cliente, a un carrello o a connessioni;
 *  - le date sono calcolate in PHP, nello stesso fuso orario usato da PrestaShop per date_add/date_upd.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CuiDbCleaner
{
    const BATCH = 5000;
    const MAX_BATCHES = 400; // massimo ~2 milioni di righe per esecuzione
    const CURSOR_GUESTS = 'CUI_CURSOR_GUESTS';

    /** @var int ampiezza dell'intervallo di id elaborato per volta nella pulizia ospiti */
    public static $guestChunk = 50000;

    /** @var array<string,bool> */
    private static $tableCache = [];

    /** tabelle semplici: chiave => [tabella senza prefisso, colonna data] */
    private static $simple = [
        'db_log' => ['log', 'date_add'],
        'db_pagenotfound' => ['pagenotfound', 'date_add'],
        'db_statssearch' => ['statssearch', 'date_add'],
        'db_mail' => ['mail', 'date_add'],
    ];

    /**
     * @param string   $key
     * @param int|null $days
     * @param bool     $doDelete
     *
     * @return array
     */
    public static function run($key, $days, $doDelete)
    {
        $limit = date('Y-m-d H:i:s', time() - (int) $days * 86400);

        if (isset(self::$simple[$key])) {
            return self::runSimple(self::$simple[$key][0], self::$simple[$key][1], $limit, $doDelete);
        }

        switch ($key) {
            case 'db_connections':
                return self::runConnections($limit, $doDelete);
            case 'db_guests':
                return self::runGuests($doDelete);
            case 'db_carts':
                return self::runCarts($limit, $doDelete);
            case 'db_expired_prices':
                return self::runExpiredPrices($doDelete);
            case 'db_page_viewed':
                return self::runPageViewed($limit, $doDelete);
            case 'db_stats_orphans':
                return self::runOrphanSpecs(self::statsOrphanSpecs(), $doDelete, null);
            case 'db_orphan_products':
                return self::runOrphanSpecs(self::productOrphanSpecs(), $doDelete, 'product');
        }

        throw new RuntimeException('Pulizia sconosciuta: ' . $key);
    }

    /**
     * OPTIMIZE TABLE sulle tabelle indicate (libera lo spazio su disco dopo grosse eliminazioni).
     *
     * @param string[] $tables nomi completi di prefisso
     *
     * @return string[] tabelle ottimizzate
     */
    public static function optimize(array $tables)
    {
        $done = [];
        foreach (array_unique($tables) as $table) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
                continue;
            }
            Db::getInstance()->executeS('OPTIMIZE TABLE `' . $table . '`', true, false);
            $done[] = $table;
        }

        return $done;
    }

    // ---------------------------------------------------------------- task semplici

    private static function runSimple($table, $dateCol, $limit, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists($table)) {
            return self::missing($res, $table);
        }
        $t = self::t($table);
        $where = '`' . $dateCol . '` < \'' . pSQL($limit) . '\'';
        $res['tables'] = [_DB_PREFIX_ . $table];
        $res['count'] = self::scalar('SELECT COUNT(*) FROM ' . $t . ' WHERE ' . $where);

        if ($doDelete && $res['count'] > 0) {
            $res['deleted'] = self::deleteBatched('DELETE FROM ' . $t . ' WHERE ' . $where . ' LIMIT ' . self::BATCH);
            self::noteRemaining($res);
        }

        return $res;
    }

    // ---------------------------------------------------------------- statistiche visite

    private static function runConnections($limit, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists('connections')) {
            return self::missing($res, 'connections');
        }
        $res['tables'] = [_DB_PREFIX_ . 'connections'];
        $hasPage = self::tableExists('connections_page');
        $hasSource = self::tableExists('connections_source');
        if ($hasPage) {
            $res['tables'][] = _DB_PREFIX_ . 'connections_page';
        }
        if ($hasSource) {
            $res['tables'][] = _DB_PREFIX_ . 'connections_source';
        }

        $where = 'date_add < \'' . pSQL($limit) . '\'';
        $res['count'] = self::scalar('SELECT COUNT(*) FROM ' . self::t('connections') . ' WHERE ' . $where);
        $res['note'] = 'Comprende le tabelle connections, connections_page e connections_source.';

        if (!$doDelete) {
            return $res;
        }

        $deleted = 0;
        for ($i = 0; $i < self::MAX_BATCHES; ++$i) {
            if (CuiCleanupManager::timeUp()) {
                break;
            }
            $ids = self::ids('SELECT id_connections FROM ' . self::t('connections') . ' WHERE ' . $where . ' LIMIT ' . self::BATCH);
            if (empty($ids)) {
                break;
            }
            $in = implode(',', $ids);
            if ($hasPage) {
                self::exec('DELETE FROM ' . self::t('connections_page') . ' WHERE id_connections IN (' . $in . ')');
            }
            if ($hasSource) {
                self::exec('DELETE FROM ' . self::t('connections_source') . ' WHERE id_connections IN (' . $in . ')');
            }
            self::exec('DELETE FROM ' . self::t('connections') . ' WHERE id_connections IN (' . $in . ')');
            $n = Db::getInstance()->Affected_Rows();
            if ($n <= 0) {
                break;
            }
            $deleted += $n;
        }
        if ($hasSource) {
            // sorgenti vecchie rimaste senza connessione
            self::deleteBatched('DELETE FROM ' . self::t('connections_source') . ' WHERE ' . $where . ' LIMIT ' . self::BATCH);
        }
        $res['deleted'] = $deleted;
        self::noteRemaining($res);

        return $res;
    }

    // ---------------------------------------------------------------- ospiti

    private static function guestWhere()
    {
        return '(g.id_customer IS NULL OR g.id_customer = 0)'
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('connections') . ' c WHERE c.id_guest = g.id_guest)'
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('cart') . ' ca WHERE ca.id_guest = g.id_guest)';
    }

    private static function runGuests($doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists('guest')) {
            return self::missing($res, 'guest');
        }
        $res['tables'] = [_DB_PREFIX_ . 'guest'];
        $res['note'] = 'Solo ospiti senza cliente, senza carrello e senza connessioni registrate.';

        if (!$doDelete) {
            $res['count'] = self::scalar('SELECT COUNT(*) FROM ' . self::t('guest') . ' g WHERE ' . self::guestWhere());

            return $res;
        }

        // Eliminazione per intervalli di id: la tabella viene scorsa una volta sola, senza rileggere a ogni
        // lotto i record da tenere (con milioni di righe e' molto piu' veloce). L'ultimo id elaborato viene
        // salvato, cosi' un'esecuzione interrotta riprende da dove si era fermata.
        $max = self::scalar('SELECT MAX(id_guest) FROM ' . self::t('guest'));
        $cursor = (int) Configuration::getGlobalValue(self::CURSOR_GUESTS);
        if ($cursor >= $max) {
            $cursor = 0;
        }
        $deleted = 0;
        $guest = self::t('guest');
        while ($cursor < $max && !CuiCleanupManager::timeUp()) {
            $to = min($max, $cursor + max(1, (int) self::$guestChunk));
            self::exec(
                'DELETE FROM ' . $guest . ' WHERE id_guest > ' . (int) $cursor . ' AND id_guest <= ' . (int) $to
                . ' AND (id_customer IS NULL OR id_customer = 0)'
                . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('connections') . ' c WHERE c.id_guest = ' . $guest . '.id_guest)'
                . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('cart') . ' ca WHERE ca.id_guest = ' . $guest . '.id_guest)'
            );
            $n = Db::getInstance()->Affected_Rows();
            if ($n > 0) {
                $deleted += $n;
            }
            $cursor = $to;
            Configuration::updateGlobalValue(self::CURSOR_GUESTS, $cursor);
        }

        $res['deleted'] = $deleted;
        $res['count'] = $deleted;
        if ($cursor < $max) {
            $res['partial'] = true;
            $res['note'] .= sprintf(' Elaborati gli id fino a %d su %d: rilancia per continuare.', $cursor, $max);
        } else {
            Configuration::updateGlobalValue(self::CURSOR_GUESTS, 0);
        }

        return $res;
    }

    // ---------------------------------------------------------------- carrelli abbandonati

    private static function cartWhere($limit)
    {
        return 'c.date_upd < \'' . pSQL($limit) . '\''
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('orders') . ' o WHERE o.id_cart = c.id_cart)'
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('customization') . ' cu WHERE cu.id_cart = c.id_cart)'
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('message') . ' m WHERE m.id_cart = c.id_cart)'
            . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('specific_price') . ' sp WHERE sp.id_cart = c.id_cart)';
    }

    private static function runCarts($limit, $doDelete)
    {
        // Mai toccare i carrelli aggiornati nell'ultima ora, nemmeno con 0 giorni: sono clienti che stanno acquistando.
        $cap = date('Y-m-d H:i:s', time() - 3600);
        if ($limit > $cap) {
            $limit = $cap;
        }

        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists('cart')) {
            return self::missing($res, 'cart');
        }
        $res['tables'] = [_DB_PREFIX_ . 'cart', _DB_PREFIX_ . 'cart_product', _DB_PREFIX_ . 'cart_cart_rule'];

        $carts = self::scalar('SELECT COUNT(*) FROM ' . self::t('cart') . ' c WHERE ' . self::cartWhere($limit));
        $orphanProducts = self::scalar(
            'SELECT COUNT(*) FROM ' . self::t('cart_product') . ' cp LEFT JOIN ' . self::t('cart')
            . ' c ON c.id_cart = cp.id_cart WHERE c.id_cart IS NULL'
        );
        $res['count'] = $carts + $orphanProducts;
        $res['note'] = sprintf(
            'Carrelli senza ordine, personalizzazioni, messaggi o prezzi specifici: %d, righe prodotto orfane: %d.',
            $carts,
            $orphanProducts
        );

        if (!$doDelete) {
            return $res;
        }

        $deleted = 0;
        for ($i = 0; $i < self::MAX_BATCHES; ++$i) {
            if (CuiCleanupManager::timeUp()) {
                break;
            }
            $ids = self::ids('SELECT c.id_cart FROM ' . self::t('cart') . ' c WHERE ' . self::cartWhere($limit) . ' LIMIT ' . self::BATCH);
            if (empty($ids)) {
                break;
            }
            $in = implode(',', $ids);
            self::exec('DELETE FROM ' . self::t('cart_product') . ' WHERE id_cart IN (' . $in . ')');
            if (self::tableExists('cart_cart_rule')) {
                self::exec('DELETE FROM ' . self::t('cart_cart_rule') . ' WHERE id_cart IN (' . $in . ')');
            }
            self::exec('DELETE FROM ' . self::t('cart') . ' WHERE id_cart IN (' . $in . ')');
            $n = Db::getInstance()->Affected_Rows();
            if ($n <= 0) {
                break;
            }
            $deleted += $n;
        }

        if ($orphanProducts > 0 && !CuiCleanupManager::timeUp()) {
            self::exec(
                'DELETE cp FROM ' . self::t('cart_product') . ' cp LEFT JOIN ' . self::t('cart')
                . ' c ON c.id_cart = cp.id_cart WHERE c.id_cart IS NULL'
            );
            $deleted += max(0, Db::getInstance()->Affected_Rows());
        }
        $res['deleted'] = $deleted;
        self::noteRemaining($res);

        return $res;
    }

    // ---------------------------------------------------------------- prezzi specifici scaduti

    private static function runExpiredPrices($doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists('specific_price')) {
            return self::missing($res, 'specific_price');
        }
        $res['tables'] = [_DB_PREFIX_ . 'specific_price'];
        $where = '`to` IS NOT NULL AND `to` > \'1970-01-02 00:00:00\' AND `to` < \'' . pSQL(date('Y-m-d H:i:s')) . '\'';
        $res['count'] = self::scalar('SELECT COUNT(*) FROM ' . self::t('specific_price') . ' WHERE ' . $where);

        if ($doDelete && $res['count'] > 0) {
            $res['deleted'] = self::deleteBatched('DELETE FROM ' . self::t('specific_price') . ' WHERE ' . $where . ' LIMIT ' . self::BATCH);
            self::noteRemaining($res);
        }

        return $res;
    }

    // ---------------------------------------------------------------- pagine viste (statsdata)

    private static function runPageViewed($limit, $doDelete)
    {
        $res = CuiCleanupManager::emptyResult();
        if (!self::tableExists('page_viewed') || !self::tableExists('date_range')) {
            return self::missing($res, 'page_viewed');
        }
        $res['tables'] = [_DB_PREFIX_ . 'page_viewed', _DB_PREFIX_ . 'date_range'];

        // date_range contiene un periodo per giorno: pochi record, quindi si possono leggere tutti gli id
        $ranges = self::ids(
            'SELECT id_date_range FROM ' . self::t('date_range') . ' WHERE time_end < \'' . pSQL($limit) . '\' LIMIT 20000'
        );
        if (empty($ranges)) {
            return $res;
        }
        $in = implode(',', $ranges);
        $views = self::scalar('SELECT COUNT(*) FROM ' . self::t('page_viewed') . ' WHERE id_date_range IN (' . $in . ')');
        $res['count'] = $views + count($ranges);
        $res['note'] = sprintf('Contatori delle pagine viste di %d giorni.', count($ranges));

        if (!$doDelete) {
            return $res;
        }

        $deleted = self::deleteBatched(
            'DELETE FROM ' . self::t('page_viewed') . ' WHERE id_date_range IN (' . $in . ') LIMIT ' . self::BATCH
        );
        if (!CuiCleanupManager::timeUp()) {
            self::exec(
                'DELETE FROM ' . self::t('date_range') . ' WHERE id_date_range IN (' . $in . ')'
                . ' AND NOT EXISTS (SELECT 1 FROM ' . self::t('page_viewed') . ' pv WHERE pv.id_date_range = '
                . self::t('date_range') . '.id_date_range)'
            );
            $deleted += max(0, Db::getInstance()->Affected_Rows());
        }
        $res['deleted'] = $deleted;
        self::noteRemaining($res);

        return $res;
    }

    // ---------------------------------------------------------------- residui senza elemento principale

    /**
     * Condizione "il record padre non esiste": $parentCol e' la colonna del padre confrontata con $col.
     */
    private static function missingParent($table, $col, $parent, $parentCol)
    {
        return 'NOT EXISTS (SELECT 1 FROM ' . self::t($parent) . ' p WHERE p.`' . $parentCol . '` = ' . self::t($table) . '.`' . $col . '`)';
    }

    /**
     * @return array<int,array{0:string,1:string,2:string[]}> [tabella, condizione, tabelle necessarie]
     */
    private static function statsOrphanSpecs()
    {
        return [
            ['connections_page', self::missingParent('connections_page', 'id_connections', 'connections', 'id_connections'), ['connections']],
            ['connections_source', self::missingParent('connections_source', 'id_connections', 'connections', 'id_connections'), ['connections']],
            ['referrer_cache', self::missingParent('referrer_cache', 'id_connections_source', 'connections_source', 'id_connections_source'), ['connections_source']],
        ];
    }

    /**
     * Righe che puntano a un prodotto (o a un'immagine / combinazione di un prodotto) che non esiste piu'.
     * Le condizioni passano sempre dalla tabella product: l'ordine di eliminazione non conta.
     *
     * @return array<int,array{0:string,1:string,2:string[]}>
     */
    private static function productOrphanSpecs()
    {
        $specs = [];
        foreach (['image', 'category_product', 'feature_product', 'product_lang', 'product_shop', 'product_attribute',
            'stock_available', 'product_tag', 'product_supplier', 'product_carrier', 'cart_product', 'customization',
            'search_index', 'product_attachment', 'product_sale', ] as $table) {
            $specs[] = [$table, self::missingParent($table, 'id_product', 'product', 'id_product'), ['product']];
        }
        // prezzi specifici di un prodotto eliminato (id_product = 0 significa "tutti i prodotti": mai toccati)
        $specs[] = ['specific_price', 'id_product > 0 AND ' . self::missingParent('specific_price', 'id_product', 'product', 'id_product'), ['product']];
        foreach (['image_shop', 'image_lang'] as $table) {
            $specs[] = [$table, 'NOT EXISTS (SELECT 1 FROM ' . self::t('image') . ' i INNER JOIN ' . self::t('product')
                . ' p ON p.id_product = i.id_product WHERE i.id_image = ' . self::t($table) . '.id_image)', ['image', 'product']];
        }
        foreach (['product_attribute_shop', 'product_attribute_combination', 'product_attribute_image'] as $table) {
            $specs[] = [$table, 'NOT EXISTS (SELECT 1 FROM ' . self::t('product_attribute') . ' a INNER JOIN ' . self::t('product')
                . ' p ON p.id_product = a.id_product WHERE a.id_product_attribute = ' . self::t($table) . '.id_product_attribute)',
                ['product_attribute', 'product', ], ];
        }

        return $specs;
    }

    /**
     * @param array       $specs
     * @param bool        $doDelete
     * @param string|null $guardTable se indicata, tabella che deve contenere almeno una riga (altrimenti non si elimina nulla)
     */
    private static function runOrphanSpecs(array $specs, $doDelete, $guardTable)
    {
        $res = CuiCleanupManager::emptyResult();
        if ($guardTable !== null) {
            if (!self::tableExists($guardTable)) {
                return self::missing($res, $guardTable);
            }
            if (self::scalar('SELECT COUNT(*) FROM ' . self::t($guardTable)) === 0) {
                $res['status'] = 'skipped';
                $res['note'] = 'Tabella ' . _DB_PREFIX_ . $guardTable . ' vuota: per sicurezza non elimino nulla.';

                return $res;
            }
        }

        $parts = [];
        $deleted = 0;
        foreach ($specs as $spec) {
            list($table, $cond, $need) = $spec;
            $ok = self::tableExists($table);
            foreach ($need as $n) {
                $ok = $ok && self::tableExists($n);
            }
            if (!$ok) {
                continue;
            }
            $count = self::scalar('SELECT COUNT(*) FROM ' . self::t($table) . ' WHERE ' . $cond);
            if ($count <= 0) {
                continue;
            }
            $res['count'] += $count;
            $res['tables'][] = _DB_PREFIX_ . $table;
            $parts[] = $table . ': ' . $count;
            if ($doDelete && !CuiCleanupManager::timeUp()) {
                $deleted += self::deleteBatched('DELETE FROM ' . self::t($table) . ' WHERE ' . $cond . ' LIMIT ' . self::BATCH);
            }
        }
        $res['deleted'] = $deleted;
        if (!empty($parts)) {
            $res['note'] = 'Righe orfane per tabella - ' . implode(', ', $parts) . '.';
        }
        if ($doDelete) {
            self::noteRemaining($res);
        }

        return $res;
    }

    // ---------------------------------------------------------------- utilita'

    private static function t($table)
    {
        return '`' . _DB_PREFIX_ . $table . '`';
    }

    private static function tableExists($table)
    {
        if (!isset(self::$tableCache[$table])) {
            self::$tableCache[$table] = (bool) Db::getInstance()->getValue(
                'SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \''
                . pSQL(_DB_PREFIX_ . $table) . '\'',
                false
            );
        }

        return self::$tableCache[$table];
    }

    private static function missing(array $res, $table)
    {
        $res['status'] = 'skipped';
        $res['note'] = 'Tabella ' . _DB_PREFIX_ . $table . ' non presente (modulo non installato): nulla da fare.';

        return $res;
    }

    private static function scalar($sql)
    {
        return (int) Db::getInstance()->getValue($sql, false);
    }

    /**
     * @return int[]
     */
    private static function ids($sql)
    {
        $rows = Db::getInstance()->executeS($sql, true, false);
        $ids = [];
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $ids[] = (int) reset($row);
            }
        }

        return $ids;
    }

    private static function exec($sql)
    {
        if (!Db::getInstance()->execute($sql, false)) {
            throw new RuntimeException('Errore database: ' . Db::getInstance()->getMsgError());
        }
    }

    /**
     * Ripete un DELETE ... LIMIT finche' non ci sono piu' righe.
     */
    private static function deleteBatched($sql)
    {
        $deleted = 0;
        for ($i = 0; $i < self::MAX_BATCHES; ++$i) {
            if (CuiCleanupManager::timeUp()) {
                break;
            }
            self::exec($sql);
            $n = Db::getInstance()->Affected_Rows();
            if ($n <= 0) {
                break;
            }
            $deleted += $n;
        }

        return $deleted;
    }

    private static function noteRemaining(array &$res)
    {
        if ($res['deleted'] < $res['count']) {
            $res['note'] = trim($res['note'] . ' Rimangono ' . ($res['count'] - $res['deleted'])
                . ' righe: rilancia la pulizia per continuare (limite di tempo o di righe per esecuzione raggiunto).');
        }
    }
}
